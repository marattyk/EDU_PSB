1) установка необходимых библиотек
pip install fastapi==0.104.1
pip install uvicorn==0.24.0
pip install pydantic==2.5.0
pip install python-multipart==0.0.6
pip install fastapi uvicorn sqlite3
2) Запустить файл EDU/documentation/main.py
3) Открыть http://localhost:8000/
4) Логины и пароли для входа указаны под строкой ввода пароля
