from fastapi import FastAPI, HTTPException, Depends, UploadFile, File, Form, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
import sqlite3
import uuid
import os
import json
from datetime import datetime, timedelta
from enum import Enum
from typing import List, Dict, Optional
from pydantic import BaseModel
import uuid
import shutil
from datetime import datetime
from typing import List, Optional
import zipfile

app = FastAPI(title="EduPlatform API")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files and uploads
os.makedirs("static", exist_ok=True)
os.makedirs("uploads", exist_ok=True)
os.makedirs("scorm_packages", exist_ok=True)
os.makedirs("talent_exchange", exist_ok=True)
app.mount("/static", StaticFiles(directory="static"), name="static")


# Database initialization
def init_db():
    conn = sqlite3.connect('lms.db')
    cursor = conn.cursor()

    # Users table - добавляем поле department
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            email TEXT UNIQUE,
            password TEXT,
            role TEXT,
            name TEXT,
            group_name TEXT,
            department TEXT
        )
    ''')

    # Courses table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS courses (
            id TEXT PRIMARY KEY,
            title TEXT,
            description TEXT,
            teacher_id TEXT,
            created_at TEXT
        )
    ''')

    # Materials table with versioning
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS materials (
            id TEXT PRIMARY KEY,
            course_id TEXT,
            title TEXT,
            content TEXT,
            material_type TEXT,
            file_path TEXT,
            version INTEGER DEFAULT 1,
            is_current BOOLEAN DEFAULT TRUE,
            created_at TEXT
        )
    ''')

    # Assignments table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS assignments (
            id TEXT PRIMARY KEY,
            course_id TEXT,
            title TEXT,
            description TEXT,
            deadline TEXT,
            max_score INTEGER,
            created_at TEXT
        )
    ''')

    # Submissions table with versioning
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS submissions (
            id TEXT PRIMARY KEY,
            assignment_id TEXT,
            student_id TEXT,
            file_path TEXT,
            version INTEGER DEFAULT 1,
            submitted_at TEXT,
            score INTEGER,
            feedback TEXT,
            is_current BOOLEAN DEFAULT TRUE
        )
    ''')

    # Progress table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS progress (
            id TEXT PRIMARY KEY,
            student_id TEXT,
            course_id TEXT,
            material_id TEXT,
            completed BOOLEAN DEFAULT FALSE,
            completed_at TEXT
        )
    ''')

    # Tests table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS tests (
            id TEXT PRIMARY KEY,
            course_id TEXT,
            title TEXT,
            description TEXT,
            questions JSON,
            created_at TEXT
        )
    ''')

    # Test results table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS test_results (
            id TEXT PRIMARY KEY,
            test_id TEXT,
            student_id TEXT,
            answers JSON,
            score INTEGER,
            max_score INTEGER,
            submitted_at TEXT
        )
    ''')

    # Chat messages table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS chat_messages (
            id TEXT PRIMARY KEY,
            group_id TEXT,
            user_id TEXT,
            message TEXT,
            created_at TEXT
        )
    ''')

    # SCORM packages table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS scorm_packages (
            id TEXT PRIMARY KEY,
            course_id TEXT,
            title TEXT,
            file_path TEXT,
            uploaded_by TEXT,
            uploaded_at TEXT
        )
    ''')

    # Talent Exchange tables
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS course_mentors (
            id TEXT PRIMARY KEY,
            course_id TEXT,
            student_id TEXT,
            specialization_tags TEXT,
            is_active BOOLEAN DEFAULT TRUE,
            assigned_by TEXT,
            assigned_at TEXT
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS talent_help_tickets (
            id TEXT PRIMARY KEY,
            title TEXT,
            description TEXT,
            author_id TEXT,
            course_id TEXT,
            project_id TEXT,
            topic_tags TEXT,
            urgency INTEGER DEFAULT 1,
            reward_amount INTEGER DEFAULT 10,
            status TEXT DEFAULT 'open',
            help_type TEXT,
            created_at TEXT,
            accepted_at TEXT,
            completed_at TEXT,
            mentor_id TEXT,
            attached_files TEXT DEFAULT '[]'
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS talent_help_sessions (
            id TEXT PRIMARY KEY,
            ticket_id TEXT,
            mentor_id TEXT,
            student_id TEXT,
            start_time TEXT,
            end_time TEXT,
            session_type TEXT,
            status TEXT DEFAULT 'in_progress',
            solution_summary TEXT
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS talent_reviews (
            id TEXT PRIMARY KEY,
            session_id TEXT,
            reviewer_id TEXT,
            reviewee_id TEXT,
            rating INTEGER,
            comment TEXT,
            created_at TEXT
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS talent_development_points (
            user_id TEXT PRIMARY KEY,
            total_points INTEGER DEFAULT 0,
            earned_total INTEGER DEFAULT 0,
            spent_total INTEGER DEFAULT 0,
            expertise_points INTEGER DEFAULT 0,
            teamwork_points INTEGER DEFAULT 0,
            leadership_points INTEGER DEFAULT 0,
            innovation_points INTEGER DEFAULT 0,
            last_updated TEXT
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS talent_mentor_stats (
            user_id TEXT PRIMARY KEY,
            rating REAL DEFAULT 5.0,
            completed_sessions INTEGER DEFAULT 0,
            response_time_avg REAL DEFAULT 0.0,
            success_rate REAL DEFAULT 0.0,
            total_reviews INTEGER DEFAULT 0
        )
    ''')

    # Insert sample data
    cursor.execute("SELECT COUNT(*) FROM users")
    if cursor.fetchone()[0] == 0:
        # Add sample teacher
        cursor.execute(
            "INSERT INTO users (id, email, password, role, name, department) VALUES (?, ?, ?, ?, ?, ?)",
            ("teacher1", "teacher@edu.ru", "pass", "teacher", "Иванов П.С.", "Преподаватели")
        )
        # Add sample student
        cursor.execute(
            "INSERT INTO users (id, email, password, role, name, group_name, department) VALUES (?, ?, ?, ?, ?, ?, ?)",
            ("student1", "student@edu.ru", "pass", "student", "Петров А.И.", "Группа 101", "Риск-менеджмент")
        )
        # Add sample student with mentor status
        cursor.execute(
            "INSERT INTO users (id, email, password, role, name, group_name, department) VALUES (?, ?, ?, ?, ?, ?, ?)",
            ("student2", "mentor_student@edu.ru", "pass", "student", "Сидоров И.В.", "Группа 101", "Риск-менеджмент")
        )
        # Add sample course
        cursor.execute(
            "INSERT INTO courses (id, title, description, teacher_id, created_at) VALUES (?, ?, ?, ?, ?)",
            ("course1", "Введение в Python", "Базовый курс программирования на Python", "teacher1",
             datetime.now().isoformat())
        )
        # Add sample materials
        cursor.execute(
            "INSERT INTO materials (id, course_id, title, content, material_type, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            ("material1", "course1", "Первые шаги в Python", "Содержание лекции по основам Python...", "text",
             datetime.now().isoformat())
        )
        cursor.execute(
            "INSERT INTO materials (id, course_id, title, content, material_type, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            ("material2", "course1", "Переменные и типы данных", "Изучаем основные типы данных в Python...", "text",
             datetime.now().isoformat())
        )
        # Add sample assignment
        cursor.execute(
            "INSERT INTO assignments (id, course_id, title, description, deadline, max_score, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            ("assignment1", "course1", "Домашняя работа 1", "Решите задачи по основам Python", "2024-12-31", 100,
             datetime.now().isoformat())
        )
        # Add sample test
        sample_questions = json.dumps([
            {
                "id": "1",
                "question": "Что выведет print(2 + 2 * 2)?",
                "type": "single",
                "options": ["6", "8", "4", "Ошибка"],
                "correct_answer": "6"
            },
            {
                "id": "2",
                "question": "Какие из перечисленных являются типами данных в Python?",
                "type": "multiple",
                "options": ["int", "string", "float", "double"],
                "correct_answers": ["int", "float"]
            }
        ])
        cursor.execute(
            "INSERT INTO tests (id, course_id, title, description, questions, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            ("test1", "course1", "Тест по основам Python", "Проверка базовых знаний Python", sample_questions,
             datetime.now().isoformat())
        )
        # Add sample mentor assignment
        cursor.execute(
            "INSERT INTO course_mentors (id, course_id, student_id, specialization_tags, assigned_by, assigned_at) VALUES (?, ?, ?, ?, ?, ?)",
            (str(uuid.uuid4()), "course1", "student2", '["python", "risk_management"]', "teacher1",
             datetime.now().isoformat())
        )
        # Add sample development points
        cursor.execute(
            "INSERT INTO talent_development_points (user_id, total_points, earned_total, expertise_points, teamwork_points, leadership_points, innovation_points, last_updated) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            ("student1", 150, 150, 50, 60, 20, 20, datetime.now().isoformat())
        )
        cursor.execute(
            "INSERT INTO talent_development_points (user_id, total_points, earned_total, expertise_points, teamwork_points, leadership_points, innovation_points, last_updated) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            ("student2", 300, 300, 100, 120, 50, 30, datetime.now().isoformat())
        )
        cursor.execute(
            "INSERT INTO talent_mentor_stats (user_id, completed_sessions, success_rate, total_reviews) VALUES (?, ?, ?, ?)",
            ("student2", 5, 0.95, 5)
        )

    conn.commit()
    conn.close()


init_db()


# Dependency to get database connection
def get_db():
    conn = sqlite3.connect('lms.db')
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()


# WebSocket connections for chat
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def send_personal_message(self, message: str, websocket: WebSocket):
        await websocket.send_text(message)

    async def broadcast(self, message: str):
        for connection in self.active_connections:
            try:
                await connection.send_text(message)
            except:
                self.active_connections.remove(connection)


manager = ConnectionManager()


# Enums for Talent Exchange
class MentorStatus(str, Enum):
    NONE = "none"
    JUNIOR_MENTOR = "junior_mentor"
    SENIOR_MENTOR = "senior_mentor"


class TicketStatus(str, Enum):
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    DISPUTED = "disputed"
    CANCELLED = "cancelled"


class HelpType(str, Enum):
    CONSULTATION = "consultation"
    SOLUTION_REVIEW = "solution_review"
    PRACTICAL_DEMO = "practical_demo"
    CODE_REVIEW = "code_review"


class CompetenceVector(str, Enum):
    EXPERTISE = "expertise"
    TEAMWORK = "teamwork"
    LEADERSHIP = "leadership"
    INNOVATION = "innovation"


class Level(str, Enum):
    TRAINEE = "trainee"
    SPECIALIST = "specialist"
    EXPERT = "expert"
    LEADER = "leader"


# Pydantic models for Talent Exchange
class DevelopmentPoints(BaseModel):
    user_id: str
    total_points: int = 0
    earned_total: int = 0
    spent_total: int = 0
    expertise_points: int = 0
    teamwork_points: int = 0
    leadership_points: int = 0
    innovation_points: int = 0


class HelpTicketCreate(BaseModel):
    title: str
    description: str
    course_id: Optional[str] = None
    project_id: Optional[str] = None
    topic_tags: List[str] = []
    urgency: int = 1
    reward_amount: int = 10
    help_type: HelpType = HelpType.CONSULTATION


class ReviewCreate(BaseModel):
    rating: int
    comment: str


class MentorAssignment(BaseModel):
    student_id: str
    course_id: str
    specialization_tags: List[str]
    is_active: bool = True


# Pydantic model for login
class LoginRequest(BaseModel):
    email: str
    password: str


# Pydantic model for test creation
class TestCreate(BaseModel):
    title: str
    description: str
    questions: List[Dict]


# Talent Exchange Business Logic
class BankingTalentExchange:
    def __init__(self, db):
        self.db = db
        self.point_rules = {
            "module_completion": 10,
            "task_solution": {"easy": 15, "medium": 20, "hard": 30},
            "project_defense": 50,
            "error_found": 20,
            "help_request_solved": 15,
            "positive_review": 10,
            "solution_to_knowledge_base": 25,
            "workshop_organized": 30,
            "mentorship": 40,
            "group_coordination": 50,
            "improvement_accepted": 60,
            "conflict_resolved": 45,
            "tool_developed": 40,
            "creative_solution": 35,
            "idea_implemented": 100,
            "balanced_development_bonus": 50
        }

        self.level_thresholds = {
            Level.TRAINEE: 0,
            Level.SPECIALIST: 200,
            Level.EXPERT: 450,
            Level.LEADER: 750
        }

    def _award_points(self, user_id: str, points: int, vector: CompetenceVector):
        """Начисление баллов развития"""
        points_data = self.db.execute(
            "SELECT * FROM talent_development_points WHERE user_id = ?", (user_id,)
        ).fetchone()

        if not points_data:
            # Create new record
            self.db.execute(
                """INSERT INTO talent_development_points 
                (user_id, total_points, earned_total, expertise_points, teamwork_points, leadership_points, innovation_points, last_updated) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (user_id, points, points,
                 points if vector == CompetenceVector.EXPERTISE else 0,
                 points if vector == CompetenceVector.TEAMWORK else 0,
                 points if vector == CompetenceVector.LEADERSHIP else 0,
                 points if vector == CompetenceVector.INNOVATION else 0,
                 datetime.now().isoformat())
            )
        else:
            # Update existing record
            update_fields = {
                "total_points": points_data["total_points"] + points,
                "earned_total": points_data["earned_total"] + points,
                "last_updated": datetime.now().isoformat()
            }

            vector_field = f"{vector.value}_points"
            update_fields[vector_field] = points_data[vector_field] + points

            set_clause = ", ".join([f"{k} = ?" for k in update_fields.keys()])
            values = list(update_fields.values()) + [user_id]

            self.db.execute(
                f"UPDATE talent_development_points SET {set_clause} WHERE user_id = ?",
                values
            )

        self.db.commit()

    def get_user_level(self, user_id: str) -> Level:
        """Определение уровня пользователя"""
        points_data = self.db.execute(
            "SELECT total_points FROM talent_development_points WHERE user_id = ?", (user_id,)
        ).fetchone()

        if not points_data:
            return Level.TRAINEE

        total_points = points_data["total_points"]

        for level, threshold in sorted(self.level_thresholds.items(), key=lambda x: x[1], reverse=True):
            if total_points >= threshold:
                return level

        return Level.TRAINEE

    def get_competence_sphere(self, user_id: str) -> Dict[str, float]:
        """Получение данных для сферы компетенций"""
        points_data = self.db.execute(
            "SELECT expertise_points, teamwork_points, leadership_points, innovation_points FROM talent_development_points WHERE user_id = ?",
            (user_id,)
        ).fetchone()

        if not points_data:
            return {vector.value: 0.0 for vector in CompetenceVector}

        points_dict = {
            CompetenceVector.EXPERTISE: points_data["expertise_points"],
            CompetenceVector.TEAMWORK: points_data["teamwork_points"],
            CompetenceVector.LEADERSHIP: points_data["leadership_points"],
            CompetenceVector.INNOVATION: points_data["innovation_points"]
        }

        # Нормализуем значения для отображения в радиальной диаграмме
        max_points = max(points_dict.values()) or 1
        normalized_data = {
            vector.value: (points / max_points) * 100
            for vector, points in points_dict.items()
        }

        return normalized_data

    def is_user_mentor_for_course(self, user_id: str, course_id: str) -> bool:
        """Проверяет, является ли пользователь ментором для данного курса"""
        mentor = self.db.execute(
            "SELECT * FROM course_mentors WHERE student_id = ? AND course_id = ? AND is_active = TRUE",
            (user_id, course_id)
        ).fetchone()
        return mentor is not None

    def get_mentor_specializations(self, user_id: str, course_id: str) -> List[str]:
        """Получает специализации ментора для курса"""
        mentor = self.db.execute(
            "SELECT specialization_tags FROM course_mentors WHERE student_id = ? AND course_id = ? AND is_active = TRUE",
            (user_id, course_id)
        ).fetchone()

        if mentor:
            return json.loads(mentor["specialization_tags"])
        return []


# Исправленная функция аутентификации
@app.post("/auth/login")
async def login(login_data: LoginRequest, db=Depends(get_db)):
    print(f"Login attempt: {login_data.email}")  # Debug log

    user = db.execute(
        "SELECT * FROM users WHERE email = ? AND password = ?",
        (login_data.email, login_data.password)
    ).fetchone()

    if not user:
        print(f"User not found or wrong password: {login_data.email}")  # Debug log
        raise HTTPException(status_code=401, detail="Invalid credentials")

    print(f"User found: {user['name']}")  # Debug log
    return {
        "id": user["id"],
        "email": user["email"],
        "name": user["name"],
        "role": user["role"],
        "department": user.get("department", ""),
        "group_name": user.get("group_name", "")
    }


# Альтернативный эндпоинт для авторизации через FormData (для совместимости)
@app.post("/auth/login-form")
def login_form(email: str = Form(...), password: str = Form(...), db=Depends(get_db)):
    return login(LoginRequest(email=email, password=password), db)


@app.get("/courses")
def get_courses(db=Depends(get_db)):
    courses = db.execute("""
        SELECT c.*, u.name as teacher_name 
        FROM courses c 
        JOIN users u ON c.teacher_id = u.id
    """).fetchall()
    return [dict(course) for course in courses]


# Получить курсы преподавателя
@app.get("/teachers/{teacher_id}/courses")
def get_teacher_courses(teacher_id: str, db=Depends(get_db)):
    courses = db.execute(
        "SELECT * FROM courses WHERE teacher_id = ? ORDER BY created_at",
        (teacher_id,)
    ).fetchall()
    return [dict(course) for course in courses]


@app.get("/courses/{course_id}/materials")
def get_course_materials(course_id: str, db=Depends(get_db)):
    materials = db.execute(
        "SELECT * FROM materials WHERE course_id = ? AND is_current = TRUE ORDER BY created_at",
        (course_id,)
    ).fetchall()
    return [dict(material) for material in materials]


@app.get("/courses/{course_id}/assignments")
def get_course_assignments(course_id: str, db=Depends(get_db)):
    assignments = db.execute(
        "SELECT * FROM assignments WHERE course_id = ? ORDER BY created_at",
        (course_id,)
    ).fetchall()
    return [dict(assignment) for assignment in assignments]


# Создание задания (для преподавателя)
@app.post("/courses/{course_id}/assignments")
def create_assignment(
        course_id: str,
        title: str = Form(...),
        description: str = Form(...),
        deadline: str = Form(...),
        max_score: int = Form(100),
        teacher_id: str = Form(...),
        db=Depends(get_db)
):
    # Проверяем, что пользователь - преподаватель и владелец курса
    course = db.execute(
        "SELECT * FROM courses WHERE id = ? AND teacher_id = ?",
        (course_id, teacher_id)
    ).fetchone()

    if not course:
        raise HTTPException(status_code=403, detail="Только владелец курса может создавать задания")

    assignment_id = str(uuid.uuid4())
    db.execute(
        "INSERT INTO assignments (id, course_id, title, description, deadline, max_score, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (assignment_id, course_id, title, description, deadline, max_score, datetime.now().isoformat())
    )
    db.commit()
    return {"message": "Assignment created successfully", "assignment_id": assignment_id}


@app.post("/assignments/{assignment_id}/submit")
def submit_assignment(
        assignment_id: str,
        student_id: str = Form(...),
        file: UploadFile = File(...),
        db=Depends(get_db)
):
    # Get current version
    current_version = db.execute(
        "SELECT COALESCE(MAX(version), 0) as max_version FROM submissions WHERE assignment_id = ? AND student_id = ?",
        (assignment_id, student_id)
    ).fetchone()["max_version"]

    new_version = current_version + 1

    # Mark old versions as not current
    db.execute(
        "UPDATE submissions SET is_current = FALSE WHERE assignment_id = ? AND student_id = ?",
        (assignment_id, student_id)
    )

    # Save file
    file_extension = os.path.splitext(file.filename)[1]
    filename = f"{assignment_id}_{student_id}_v{new_version}{file_extension}"
    file_path = os.path.join("uploads", filename)

    with open(file_path, "wb") as f:
        f.write(file.file.read())

    # Save submission
    submission_id = str(uuid.uuid4())
    db.execute(
        "INSERT INTO submissions (id, assignment_id, student_id, file_path, version, submitted_at, is_current) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (submission_id, assignment_id, student_id, file_path, new_version, datetime.now().isoformat(), True)
    )
    db.commit()

    return {"message": "Assignment submitted successfully", "version": new_version}


@app.get("/students/{student_id}/submissions")
def get_student_submissions(student_id: str, db=Depends(get_db)):
    submissions = db.execute('''
        SELECT s.*, a.title as assignment_title, a.course_id
        FROM submissions s 
        JOIN assignments a ON s.assignment_id = a.id 
        WHERE s.student_id = ? AND s.is_current = TRUE
    ''', (student_id,)).fetchall()
    return [dict(submission) for submission in submissions]


@app.get("/students/{student_id}/submissions/{assignment_id}/versions")
def get_submission_versions(student_id: str, assignment_id: str, db=Depends(get_db)):
    submissions = db.execute('''
        SELECT s.*, a.title as assignment_title
        FROM submissions s 
        JOIN assignments a ON s.assignment_id = a.id 
        WHERE s.student_id = ? AND s.assignment_id = ?
        ORDER BY s.version DESC
    ''', (student_id, assignment_id)).fetchall()
    return [dict(submission) for submission in submissions]


@app.post("/materials/{material_id}/complete")
def mark_material_complete(
        material_id: str,
        student_id: str = Form(...),
        course_id: str = Form(...),
        db=Depends(get_db)
):
    # Check if already completed
    existing = db.execute(
        "SELECT * FROM progress WHERE student_id = ? AND material_id = ?",
        (student_id, material_id)
    ).fetchone()

    if not existing:
        progress_id = str(uuid.uuid4())
        db.execute(
            "INSERT INTO progress (id, student_id, course_id, material_id, completed, completed_at) VALUES (?, ?, ?, ?, ?, ?)",
            (progress_id, student_id, course_id, material_id, True, datetime.now().isoformat())
        )
        db.commit()

    return {"message": "Material marked as completed"}


@app.get("/students/{student_id}/progress/{course_id}")
def get_student_progress(student_id: str, course_id: str, db=Depends(get_db)):
    # Get total materials count
    total_materials = db.execute(
        "SELECT COUNT(*) as count FROM materials WHERE course_id = ? AND is_current = TRUE",
        (course_id,)
    ).fetchone()["count"]

    # Get completed materials count
    completed_materials = db.execute(
        "SELECT COUNT(*) as count FROM progress WHERE student_id = ? AND course_id = ? AND completed = TRUE",
        (student_id, course_id)
    ).fetchone()["count"]

    progress = (completed_materials / total_materials * 100) if total_materials > 0 else 0

    return {
        "total_materials": total_materials,
        "completed_materials": completed_materials,
        "progress": round(progress, 2)
    }


@app.get("/students/{student_id}/grades")
def get_student_grades(student_id: str, db=Depends(get_db)):
    grades = db.execute('''
        SELECT s.score, a.max_score, a.title as assignment_title, c.title as course_title,
               s.submitted_at, s.feedback
        FROM submissions s
        JOIN assignments a ON s.assignment_id = a.id
        JOIN courses c ON a.course_id = c.id
        WHERE s.student_id = ? AND s.score IS NOT NULL AND s.is_current = TRUE
        ORDER BY s.submitted_at DESC
    ''', (student_id,)).fetchall()
    return [dict(grade) for grade in grades]


# Teacher endpoints
@app.post("/courses/{course_id}/materials")
def create_material(
        course_id: str,
        title: str = Form(...),
        content: str = Form(...),
        material_type: str = Form("text"),
        teacher_id: str = Form(...),
        db=Depends(get_db)
):
    # Проверяем, что пользователь - преподаватель и владелец курса
    course = db.execute(
        "SELECT * FROM courses WHERE id = ? AND teacher_id = ?",
        (course_id, teacher_id)
    ).fetchone()

    if not course:
        raise HTTPException(status_code=403, detail="Только владелец курса может создавать материалы")

    material_id = str(uuid.uuid4())
    db.execute(
        "INSERT INTO materials (id, course_id, title, content, material_type, created_at) VALUES (?, ?, ?, ?, ?, ?)",
        (material_id, course_id, title, content, material_type, datetime.now().isoformat())
    )
    db.commit()
    return {"message": "Material created successfully"}


@app.post("/courses/{course_id}/materials/{material_id}/version")
def create_material_version(
        course_id: str,
        material_id: str,
        title: str = Form(...),
        content: str = Form(...),
        teacher_id: str = Form(...),
        db=Depends(get_db)
):
    # Проверяем, что пользователь - преподаватель и владелец курса
    course = db.execute(
        "SELECT * FROM courses WHERE id = ? AND teacher_id = ?",
        (course_id, teacher_id)
    ).fetchone()

    if not course:
        raise HTTPException(status_code=403, detail="Только владелец курса может создавать версии материалов")

    # Get current version
    current_material = db.execute(
        "SELECT * FROM materials WHERE id = ? AND is_current = TRUE",
        (material_id,)
    ).fetchone()

    if current_material:
        # Mark old version as not current
        db.execute(
            "UPDATE materials SET is_current = FALSE WHERE id = ?",
            (material_id,)
        )

    # Create new version
    new_material_id = str(uuid.uuid4())
    new_version = current_material["version"] + 1 if current_material else 1

    db.execute(
        "INSERT INTO materials (id, course_id, title, content, material_type, version, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (new_material_id, course_id, title, content, current_material["material_type"] if current_material else "text",
         new_version, datetime.now().isoformat())
    )
    db.commit()
    return {"message": "Material version created successfully", "version": new_version}


@app.get("/assignments/{assignment_id}/submissions")
def get_assignment_submissions(assignment_id: str, db=Depends(get_db)):
    submissions = db.execute('''
        SELECT s.*, u.name as student_name, u.group_name
        FROM submissions s 
        JOIN users u ON s.student_id = u.id 
        WHERE s.assignment_id = ? AND s.is_current = TRUE
    ''', (assignment_id,)).fetchall()
    return [dict(submission) for submission in submissions]


@app.post("/submissions/{submission_id}/grade")
def grade_submission(
        submission_id: str,
        score: int = Form(...),
        feedback: str = Form(...),
        teacher_id: str = Form(...),
        db=Depends(get_db)
):
    # Проверяем, что пользователь - преподаватель
    teacher = db.execute(
        "SELECT role FROM users WHERE id = ?", (teacher_id,)
    ).fetchone()

    if not teacher or teacher["role"] != "teacher":
        raise HTTPException(status_code=403, detail="Только преподаватели могут оценивать работы")

    db.execute(
        "UPDATE submissions SET score = ?, feedback = ? WHERE id = ?",
        (score, feedback, submission_id)
    )
    db.commit()
    return {"message": "Submission graded successfully"}


# Tests functionality
@app.get("/courses/{course_id}/tests")
def get_course_tests(course_id: str, db=Depends(get_db)):
    tests = db.execute(
        "SELECT * FROM tests WHERE course_id = ? ORDER BY created_at",
        (course_id,)
    ).fetchall()

    result = []
    for test in tests:
        test_dict = dict(test)
        test_dict["questions"] = json.loads(test_dict["questions"])
        result.append(test_dict)

    return result


# Создание теста (для преподавателя)
@app.post("/courses/{course_id}/tests")
def create_test(
        course_id: str,
        test_data: TestCreate,
        teacher_id: str = Form(...),
        db=Depends(get_db)
):
    # Проверяем, что пользователь - преподаватель и владелец курса
    course = db.execute(
        "SELECT * FROM courses WHERE id = ? AND teacher_id = ?",
        (course_id, teacher_id)
    ).fetchone()

    if not course:
        raise HTTPException(status_code=403, detail="Только владелец курса может создавать тесты")

    test_id = str(uuid.uuid4())
    db.execute(
        "INSERT INTO tests (id, course_id, title, description, questions, created_at) VALUES (?, ?, ?, ?, ?, ?)",
        (test_id, course_id, test_data.title, test_data.description, json.dumps(test_data.questions),
         datetime.now().isoformat())
    )
    db.commit()
    return {"message": "Test created successfully", "test_id": test_id}


@app.post("/tests/{test_id}/submit")
def submit_test(
        test_id: str,
        student_id: str = Form(...),
        answers: str = Form(...),
        db=Depends(get_db)
):
    # Get test data
    test = db.execute(
        "SELECT * FROM tests WHERE id = ?",
        (test_id,)
    ).fetchone()

    if not test:
        raise HTTPException(status_code=404, detail="Test not found")

    test_questions = json.loads(test["questions"])
    student_answers = json.loads(answers)

    # Calculate score
    score = 0
    max_score = len(test_questions)

    for question in test_questions:
        question_id = question["id"]
        if question_id in student_answers:
            if question["type"] == "single":
                if student_answers[question_id] == question["correct_answer"]:
                    score += 1
            elif question["type"] == "multiple":
                if set(student_answers[question_id]) == set(question["correct_answers"]):
                    score += 1

    # Save result
    result_id = str(uuid.uuid4())
    db.execute(
        "INSERT INTO test_results (id, test_id, student_id, answers, score, max_score, submitted_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (result_id, test_id, student_id, answers, score, max_score, datetime.now().isoformat())
    )
    db.commit()

    return {"score": score, "max_score": max_score, "message": "Test submitted successfully"}


@app.get("/students/{student_id}/test-results")
def get_student_test_results(student_id: str, db=Depends(get_db)):
    results = db.execute('''
        SELECT tr.*, t.title as test_title, c.title as course_title
        FROM test_results tr
        JOIN tests t ON tr.test_id = t.id
        JOIN courses c ON t.course_id = c.id
        WHERE tr.student_id = ?
        ORDER BY tr.submitted_at DESC
    ''', (student_id,)).fetchall()

    return [dict(result) for result in results]


# Получить результаты теста (для преподавателя)
@app.get("/tests/{test_id}/results")
def get_test_results(test_id: str, teacher_id: str, db=Depends(get_db)):
    # Проверяем, что пользователь - преподаватель и имеет доступ к тесту
    test = db.execute('''
        SELECT t.* FROM tests t
        JOIN courses c ON t.course_id = c.id
        WHERE t.id = ? AND c.teacher_id = ?
    ''', (test_id, teacher_id)).fetchone()

    if not test:
        raise HTTPException(status_code=404, detail="Test not found or access denied")

    results = db.execute('''
        SELECT tr.*, u.name as student_name, u.group_name
        FROM test_results tr
        JOIN users u ON tr.student_id = u.id
        WHERE tr.test_id = ?
        ORDER BY tr.submitted_at DESC
    ''', (test_id,)).fetchall()

    return [dict(result) for result in results]


# Chat functionality
@app.websocket("/ws/chat/{group_id}")
async def websocket_chat(websocket: WebSocket, group_id: str):
    await manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            message_data = json.loads(data)

            # Save message to database
            conn = sqlite3.connect('lms.db')
            cursor = conn.cursor()
            message_id = str(uuid.uuid4())
            cursor.execute(
                "INSERT INTO chat_messages (id, group_id, user_id, message, created_at) VALUES (?, ?, ?, ?, ?)",
                (message_id, group_id, message_data["user_id"], message_data["message"], datetime.now().isoformat())
            )
            conn.commit()
            conn.close()

            # Broadcast message
            await manager.broadcast(json.dumps({
                "type": "message",
                "user_id": message_data["user_id"],
                "message": message_data["message"],
                "timestamp": datetime.now().isoformat()
            }))
    except WebSocketDisconnect:
        manager.disconnect(websocket)


@app.get("/chat/{group_id}/messages")
def get_chat_messages(group_id: str, db=Depends(get_db)):
    messages = db.execute('''
        SELECT cm.*, u.name as user_name, u.role as user_role
        FROM chat_messages cm
        JOIN users u ON cm.user_id = u.id
        WHERE cm.group_id = ?
        ORDER BY cm.created_at ASC
        LIMIT 100
    ''', (group_id,)).fetchall()
    return [dict(message) for message in messages]


# SCORM functionality
@app.post("/courses/{course_id}/scorm")
async def upload_scorm_package(
        course_id: str,
        file: UploadFile = File(...),
        teacher_id: str = Form(...),
        db=Depends(get_db)
):
    # Check if user is teacher and course owner
    course = db.execute(
        "SELECT * FROM courses WHERE id = ? AND teacher_id = ?",
        (course_id, teacher_id)
    ).fetchone()

    if not course:
        raise HTTPException(status_code=403, detail="Только владелец курса может загружать SCORM пакеты")

    # Save SCORM package
    file_extension = os.path.splitext(file.filename)[1]
    if file_extension.lower() != '.zip':
        raise HTTPException(status_code=400, detail="Only ZIP files are allowed for SCORM packages")

    package_id = str(uuid.uuid4())
    filename = f"{package_id}{file_extension}"
    file_path = os.path.join("scorm_packages", filename)

    with open(file_path, "wb") as f:
        f.write(await file.read())

    # Extract and validate SCORM structure
    try:
        with zipfile.ZipFile(file_path, 'r') as zip_ref:
            extract_path = os.path.join("scorm_packages", package_id)
            zip_ref.extractall(extract_path)
    except:
        os.remove(file_path)
        raise HTTPException(status_code=400, detail="Invalid ZIP file")

    # Save to database
    db.execute(
        "INSERT INTO scorm_packages (id, course_id, title, file_path, uploaded_by, uploaded_at) VALUES (?, ?, ?, ?, ?, ?)",
        (package_id, course_id, file.filename, extract_path, teacher_id, datetime.now().isoformat())
    )
    db.commit()

    return {"message": "SCORM package uploaded successfully", "package_id": package_id}


@app.get("/courses/{course_id}/scorm")
def get_course_scorm_packages(course_id: str, db=Depends(get_db)):
    packages = db.execute(
        "SELECT sp.*, u.name as teacher_name FROM scorm_packages sp JOIN users u ON sp.uploaded_by = u.id WHERE sp.course_id = ?",
        (course_id,)
    ).fetchall()
    return [dict(package) for package in packages]


# Talent Exchange Routes
@app.post("/talent-exchange/assign-mentor")
def assign_course_mentor(
        assignment: MentorAssignment,
        teacher_id: str = Form(...),
        db=Depends(get_db)
):
    """Назначение студента ментором для курса (только для преподавателей)"""
    # Verify teacher
    teacher = db.execute(
        "SELECT role FROM users WHERE id = ?", (teacher_id,)
    ).fetchone()

    if not teacher or teacher["role"] != "teacher":
        raise HTTPException(status_code=403, detail="Только преподаватели могут назначать менторов")

    # Verify student exists
    student = db.execute(
        "SELECT * FROM users WHERE id = ? AND role = 'student'", (assignment.student_id,)
    ).fetchone()

    if not student:
        raise HTTPException(status_code=404, detail="Студент не найден")

    # Check if already assigned
    existing_mentor = db.execute(
        "SELECT * FROM course_mentors WHERE student_id = ? AND course_id = ?",
        (assignment.student_id, assignment.course_id)
    ).fetchone()

    if existing_mentor:
        # Update existing assignment
        db.execute(
            "UPDATE course_mentors SET specialization_tags = ?, is_active = ?, assigned_by = ?, assigned_at = ? WHERE id = ?",
            (json.dumps(assignment.specialization_tags), assignment.is_active, teacher_id, datetime.now().isoformat(),
             existing_mentor["id"])
        )
    else:
        # Create new assignment
        mentor_id = str(uuid.uuid4())
        db.execute(
            "INSERT INTO course_mentors (id, course_id, student_id, specialization_tags, is_active, assigned_by, assigned_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (mentor_id, assignment.course_id, assignment.student_id, json.dumps(assignment.specialization_tags),
             assignment.is_active, teacher_id, datetime.now().isoformat())
        )

    # Initialize mentor stats if not exists
    existing_stats = db.execute(
        "SELECT * FROM talent_mentor_stats WHERE user_id = ?", (assignment.student_id,)
    ).fetchone()

    if not existing_stats:
        db.execute(
            "INSERT INTO talent_mentor_stats (user_id) VALUES (?)",
            (assignment.student_id,)
        )

    # Initialize development points if not exists
    existing_points = db.execute(
        "SELECT * FROM talent_development_points WHERE user_id = ?", (assignment.student_id,)
    ).fetchone()

    if not existing_points:
        db.execute(
            "INSERT INTO talent_development_points (user_id, last_updated) VALUES (?, ?)",
            (assignment.student_id, datetime.now().isoformat())
        )

    db.commit()

    action = "обновлен" if existing_mentor else "назначен"
    return {"message": f"Студент успешно {action} ментором для курса"}


@app.delete("/talent-exchange/courses/{course_id}/mentors/{student_id}")
def remove_course_mentor(
        course_id: str,
        student_id: str,
        teacher_id: str = Form(...),
        db=Depends(get_db)
):
    """Удаление студента из менторов курса"""
    # Verify teacher
    teacher = db.execute(
        "SELECT role FROM users WHERE id = ?", (teacher_id,)
    ).fetchone()

    if not teacher or teacher["role"] != "teacher":
        raise HTTPException(status_code=403, detail="Только преподаватели могут удалять менторов")

    # Deactivate mentor assignment
    db.execute(
        "UPDATE course_mentors SET is_active = FALSE WHERE student_id = ? AND course_id = ?",
        (student_id, course_id)
    )
    db.commit()

    return {"message": "Ментор удален из курса"}


@app.get("/courses/{course_id}/mentors")
def get_course_mentors(course_id: str, db=Depends(get_db)):
    """Получение списка менторов для курса"""
    mentors = db.execute('''
        SELECT cm.*, u.name as student_name, u.email, u.group_name, u.department
        FROM course_mentors cm
        JOIN users u ON cm.student_id = u.id
        WHERE cm.course_id = ? AND cm.is_active = TRUE
    ''', (course_id,)).fetchall()

    result = []
    for mentor in mentors:
        mentor_dict = dict(mentor)
        mentor_dict["specialization_tags"] = json.loads(mentor_dict["specialization_tags"])
        result.append(mentor_dict)

    return result


@app.get("/users/{user_id}/mentor-courses")
def get_user_mentor_courses(user_id: str, db=Depends(get_db)):
    """Получение курсов, где пользователь является ментором"""
    mentor_courses = db.execute('''
        SELECT cm.*, c.title as course_title, c.description as course_description
        FROM course_mentors cm
        JOIN courses c ON cm.course_id = c.id
        WHERE cm.student_id = ? AND cm.is_active = TRUE
    ''', (user_id,)).fetchall()

    result = []
    for course in mentor_courses:
        course_dict = dict(course)
        course_dict["specialization_tags"] = json.loads(course_dict["specialization_tags"])
        result.append(course_dict)

    return result


@app.post("/talent-exchange/tickets")
def create_help_ticket(
        ticket_data: HelpTicketCreate,
        author_id: str = Form(...),
        db=Depends(get_db)
):
    """Создание запроса на помощь"""
    # Check if user has enough points
    points_data = db.execute(
        "SELECT total_points FROM talent_development_points WHERE user_id = ?", (author_id,)
    ).fetchone()

    if points_data and points_data["total_points"] < ticket_data.reward_amount:
        raise HTTPException(status_code=400, detail="Недостаточно баллов для создания запроса")

    # Reserve points
    if points_data:
        db.execute(
            "UPDATE talent_development_points SET total_points = total_points - ?, spent_total = spent_total + ? WHERE user_id = ?",
            (ticket_data.reward_amount, ticket_data.reward_amount, author_id)
        )

    # Create ticket
    ticket_id = str(uuid.uuid4())
    db.execute(
        """INSERT INTO talent_help_tickets 
        (id, title, description, author_id, course_id, project_id, topic_tags, urgency, reward_amount, help_type, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (ticket_id, ticket_data.title, ticket_data.description, author_id,
         ticket_data.course_id, ticket_data.project_id, json.dumps(ticket_data.topic_tags),
         ticket_data.urgency, ticket_data.reward_amount, ticket_data.help_type.value,
         datetime.now().isoformat())
    )
    db.commit()

    return {"message": "Запрос создан успешно", "ticket_id": ticket_id}


@app.get("/talent-exchange/tickets")
def get_help_tickets(
        status: Optional[TicketStatus] = None,
        course_id: Optional[str] = None,
        db=Depends(get_db)
):
    """Получение списка запросов на помощь"""
    query = """
        SELECT tht.*, u.name as author_name, u.department as author_department
        FROM talent_help_tickets tht
        JOIN users u ON tht.author_id = u.id
        WHERE 1=1
    """
    params = []

    if status:
        query += " AND tht.status = ?"
        params.append(status.value)
    if course_id:
        query += " AND tht.course_id = ?"
        params.append(course_id)

    query += " ORDER BY tht.created_at DESC"

    tickets = db.execute(query, params).fetchall()

    result = []
    for ticket in tickets:
        ticket_dict = dict(ticket)
        ticket_dict["topic_tags"] = json.loads(ticket_dict["topic_tags"])
        ticket_dict["attached_files"] = json.loads(ticket_dict["attached_files"])
        result.append(ticket_dict)

    return result


@app.post("/talent-exchange/tickets/{ticket_id}/accept")
def accept_ticket(
        ticket_id: str,
        mentor_id: str = Form(...),
        db=Depends(get_db)
):
    """Принятие запроса ментором"""
    # Check ticket availability
    ticket = db.execute(
        "SELECT * FROM talent_help_tickets WHERE id = ?", (ticket_id,)
    ).fetchone()

    if not ticket:
        raise HTTPException(status_code=404, detail="Запрос не найден")

    if ticket["status"] != TicketStatus.OPEN:
        raise HTTPException(status_code=400, detail="Запрос уже занят или закрыт")

    # Check if user is mentor for this course
    bte = BankingTalentExchange(db)
    if not bte.is_user_mentor_for_course(mentor_id, ticket["course_id"]):
        raise HTTPException(status_code=403, detail="Вы не являетесь ментором для этого курса")

    # Check mentor competence
    mentor_tags = bte.get_mentor_specializations(mentor_id, ticket["course_id"])
    ticket_tags = json.loads(ticket["topic_tags"])

    if not set(mentor_tags).intersection(set(ticket_tags)):
        raise HTTPException(status_code=400, detail="Вы не обладаете нужными компетенциями для этого запроса")

    # Update ticket
    db.execute(
        "UPDATE talent_help_tickets SET status = ?, mentor_id = ?, accepted_at = ? WHERE id = ?",
        (TicketStatus.IN_PROGRESS.value, mentor_id, datetime.now().isoformat(), ticket_id)
    )

    # Create session
    session_id = str(uuid.uuid4())
    db.execute(
        """INSERT INTO talent_help_sessions 
        (id, ticket_id, mentor_id, student_id, start_time, session_type, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (session_id, ticket_id, mentor_id, ticket["author_id"],
         datetime.now().isoformat(), ticket["help_type"], TicketStatus.IN_PROGRESS.value)
    )
    db.commit()

    return {"message": "Запрос принят успешно", "session_id": session_id}


@app.post("/talent-exchange/sessions/{session_id}/complete")
def complete_session(
        session_id: str,
        solution_summary: str = Form(...),
        db=Depends(get_db)
):
    """Завершение сессии помощи"""
    session = db.execute(
        "SELECT * FROM talent_help_sessions WHERE id = ?", (session_id,)
    ).fetchone()

    if not session:
        raise HTTPException(status_code=404, detail="Сессия не найдена")

    # Update session
    db.execute(
        "UPDATE talent_help_sessions SET end_time = ?, status = ?, solution_summary = ? WHERE id = ?",
        (datetime.now().isoformat(), TicketStatus.COMPLETED.value, solution_summary, session_id)
    )

    # Update ticket
    db.execute(
        "UPDATE talent_help_tickets SET status = ?, completed_at = ? WHERE id = ?",
        (TicketStatus.COMPLETED.value, datetime.now().isoformat(), session["ticket_id"])
    )

    # Award points to mentor
    ticket = db.execute(
        "SELECT reward_amount FROM talent_help_tickets WHERE id = ?", (session["ticket_id"],)
    ).fetchone()

    bte = BankingTalentExchange(db)
    bte._award_points(session["mentor_id"], bte.point_rules["help_request_solved"], CompetenceVector.TEAMWORK)

    # Transfer reward
    if ticket:
        db.execute(
            "UPDATE talent_development_points SET total_points = total_points + ?, earned_total = earned_total + ? WHERE user_id = ?",
            (ticket["reward_amount"], ticket["reward_amount"], session["mentor_id"])
        )

    # Update mentor stats
    mentor_stats = db.execute(
        "SELECT * FROM talent_mentor_stats WHERE user_id = ?", (session["mentor_id"],)
    ).fetchone()

    if not mentor_stats:
        db.execute(
            "INSERT INTO talent_mentor_stats (user_id, completed_sessions, success_rate) VALUES (?, ?, ?)",
            (session["mentor_id"], 1, 1.0)
        )
    else:
        new_sessions = mentor_stats["completed_sessions"] + 1
        new_success_rate = (mentor_stats["success_rate"] * mentor_stats["completed_sessions"] + 1) / new_sessions
        db.execute(
            "UPDATE talent_mentor_stats SET completed_sessions = ?, success_rate = ? WHERE user_id = ?",
            (new_sessions, new_success_rate, session["mentor_id"])
        )

    db.commit()
    return {"message": "Сессия завершена успешно"}


@app.post("/talent-exchange/sessions/{session_id}/review")
def add_session_review(
        session_id: str,
        review_data: ReviewCreate,
        reviewer_id: str = Form(...),
        db=Depends(get_db)
):
    """Добавление отзыва о сессии"""
    session = db.execute(
        "SELECT * FROM talent_help_sessions WHERE id = ?", (session_id,)
    ).fetchone()

    if not session:
        raise HTTPException(status_code=404, detail="Сессия не найдена")

    # Determine reviewee
    if reviewer_id == session["student_id"]:
        reviewee_id = session["mentor_id"]
    elif reviewer_id == session["mentor_id"]:
        reviewee_id = session["student_id"]
    else:
        raise HTTPException(status_code=400, detail="Участник не принадлежит этой сессии")

    # Create review
    review_id = str(uuid.uuid4())
    db.execute(
        "INSERT INTO talent_reviews (id, session_id, reviewer_id, reviewee_id, rating, comment, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (review_id, session_id, reviewer_id, reviewee_id, review_data.rating, review_data.comment,
         datetime.now().isoformat())
    )

    # Award points for positive review
    if reviewer_id == session["student_id"] and review_data.rating >= 4:
        bte = BankingTalentExchange(db)
        bte._award_points(reviewee_id, bte.point_rules["positive_review"], CompetenceVector.TEAMWORK)

    # Update mentor rating
    if reviewee_id != session["student_id"]:  # If reviewee is a mentor
        mentor_reviews = db.execute(
            "SELECT rating FROM talent_reviews WHERE reviewee_id = ?", (reviewee_id,)
        ).fetchall()

        if mentor_reviews:
            total_rating = sum(review["rating"] for review in mentor_reviews)
            avg_rating = total_rating / len(mentor_reviews)

            db.execute(
                "UPDATE talent_mentor_stats SET rating = ?, total_reviews = ? WHERE user_id = ?",
                (avg_rating, len(mentor_reviews), reviewee_id)
            )

    db.commit()
    return {"message": "Отзыв добавлен успешно"}


@app.get("/talent-exchange/users/{user_id}/profile")
def get_user_profile(user_id: str, db=Depends(get_db)):
    """Получение профиля пользователя с баллами развития"""
    user = db.execute(
        "SELECT id, name, email, role, department FROM users WHERE id = ?", (user_id,)
    ).fetchone()

    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    points_data = db.execute(
        "SELECT * FROM talent_development_points WHERE user_id = ?", (user_id,)
    ).fetchone()

    mentor_stats = db.execute(
        "SELECT * FROM talent_mentor_stats WHERE user_id = ?", (user_id,)
    ).fetchone()

    # Get mentor courses
    mentor_courses = db.execute('''
        SELECT cm.course_id, c.title as course_title
        FROM course_mentors cm
        JOIN courses c ON cm.course_id = c.id
        WHERE cm.student_id = ? AND cm.is_active = TRUE
    ''', (user_id,)).fetchall()

    bte = BankingTalentExchange(db)

    user_dict = dict(user)
    user_dict["level"] = bte.get_user_level(user_id)
    user_dict["competence_sphere"] = bte.get_competence_sphere(user_id)
    user_dict["mentor_courses"] = [dict(course) for course in mentor_courses]

    if points_data:
        user_dict["development_points"] = dict(points_data)

    if mentor_stats:
        user_dict["mentor_stats"] = dict(mentor_stats)

    return user_dict


@app.get("/talent-exchange/leaderboard")
def get_leaderboard(
        vector: Optional[CompetenceVector] = None,
        db=Depends(get_db)
):
    """Получение таблицы лидеров"""
    if vector:
        order_field = f"{vector.value}_points"
    else:
        order_field = "total_points"

    query = f"""
        SELECT tdp.*, u.name, u.department, u.role
        FROM talent_development_points tdp
        JOIN users u ON tdp.user_id = u.id
        ORDER BY tdp.{order_field} DESC
        LIMIT 10
    """

    leaders = db.execute(query).fetchall()

    bte = BankingTalentExchange(db)
    result = []

    for leader in leaders:
        leader_dict = dict(leader)
        leader_dict["level"] = bte.get_user_level(leader["user_id"])
        leader_dict["competence_sphere"] = bte.get_competence_sphere(leader["user_id"])
        result.append(leader_dict)

    return result


@app.post("/talent-exchange/award-achievement")
def award_special_achievement(
        user_id: str = Form(...),
        achievement_type: str = Form(...),
        vector: CompetenceVector = Form(...),
        teacher_id: str = Form(...),
        db=Depends(get_db)
):
    """Награждение за специальные достижения (только для преподавателей)"""
    # Verify teacher
    teacher = db.execute(
        "SELECT role FROM users WHERE id = ?", (teacher_id,)
    ).fetchone()

    if not teacher or teacher["role"] != "teacher":
        raise HTTPException(status_code=403, detail="Только преподаватели могут награждать достижения")

    achievement_points = {
        "module_completion": 10,
        "project_defense": 50,
        "error_found": 20,
        "workshop_organized": 30,
        "mentorship": 40,
        "group_coordination": 50,
        "improvement_accepted": 60,
        "conflict_resolved": 45,
        "tool_developed": 40,
        "creative_solution": 35,
        "idea_implemented": 100,
    }

    if achievement_type not in achievement_points:
        raise HTTPException(status_code=400, detail="Неизвестный тип достижения")

    bte = BankingTalentExchange(db)
    bte._award_points(user_id, achievement_points[achievement_type], vector)

    return {"message": "Достижение награждено успешно"}


# Новые эндпоинты для фронтэнда
@app.get("/users/students")
def get_all_students(db=Depends(get_db)):
    """Получение списка всех студентов"""
    students = db.execute(
        "SELECT id, name, email, group_name, department FROM users WHERE role = 'student'"
    ).fetchall()
    return [dict(student) for student in students]


@app.get("/admin/stats")
def get_admin_stats(db=Depends(get_db)):
    """Получение статистики платформы для админ-панели"""
    total_users = db.execute("SELECT COUNT(*) as count FROM users").fetchone()["count"]
    active_mentors = db.execute("SELECT COUNT(*) as count FROM course_mentors WHERE is_active = TRUE").fetchone()[
        "count"]
    completed_sessions = \
        db.execute("SELECT COUNT(*) as count FROM talent_help_sessions WHERE status = 'completed'").fetchone()["count"]

    return {
        "total_users": total_users,
        "active_mentors": active_mentors,
        "completed_sessions": completed_sessions
    }


@app.get("/talent-exchange/users/{user_id}/sessions")
def get_user_sessions(user_id: str, db=Depends(get_db)):
    """Получение сессий пользователя"""
    sessions = db.execute('''
        SELECT ths.*, tht.title as ticket_title, tht.description as ticket_description,
               u1.name as mentor_name, u2.name as student_name
        FROM talent_help_sessions ths
        JOIN talent_help_tickets tht ON ths.ticket_id = tht.id
        LEFT JOIN users u1 ON ths.mentor_id = u1.id
        LEFT JOIN users u2 ON ths.student_id = u2.id
        WHERE ths.mentor_id = ? OR ths.student_id = ?
        ORDER BY ths.start_time DESC
    ''', (user_id, user_id)).fetchall()

    return [dict(session) for session in sessions]


# Serve frontend
@app.get("/", response_class=HTMLResponse)
async def read_index():
    with open("static/index.html", "r", encoding="utf-8") as f:
        return HTMLResponse(content=f.read())


# Эндпоинт для проверки базы данных (для отладки)
@app.get("/debug/users")
def debug_users(db=Depends(get_db)):
    """Эндпоинт для отладки - показывает всех пользователей"""
    users = db.execute("SELECT * FROM users").fetchall()
    return [dict(user) for user in users]


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)